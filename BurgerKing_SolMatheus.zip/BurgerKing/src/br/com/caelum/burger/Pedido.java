package br.com.caelum.burger;

public class Pedido {
	
	public static enum Ingrediente {BACON, QUEIJO, TOMATE, MILHO}

	 public void realizarPedido(Ingrediente ... ingredientes){
		 StringBuilder builder = new StringBuilder("PEDIDO: Hamburguer Simples ");
		 for(Ingrediente i : ingredientes)
			 builder.append(" + ").append(i);
		 System.out.println(builder.toString());  
	 }
}
