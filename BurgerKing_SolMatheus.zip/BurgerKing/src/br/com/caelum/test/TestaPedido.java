package br.com.caelum.test;

import br.com.caelum.burger.Pedido;
import br.com.caelum.burger.Pedido.Ingrediente;

public class TestaPedido {

	public static void main(String[] args) {
		new Pedido().realizarPedido(Ingrediente.BACON, Ingrediente.TOMATE);
		new Pedido().realizarPedido(Ingrediente.BACON, Ingrediente.MILHO, Ingrediente.QUEIJO, Ingrediente.TOMATE);
		new Pedido().realizarPedido();
	}

}
